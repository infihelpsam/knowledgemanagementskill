"""Project-owned knowledge infrastructure."""
